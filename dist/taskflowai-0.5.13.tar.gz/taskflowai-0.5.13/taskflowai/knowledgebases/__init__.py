# Copyright 2024 TaskFlowAI Contributors. Licensed under Apache License 2.0.

from .faiss_knowledgebase import FaissKnowledgeBase

__all__ = ['FaissKnowledgeBase']



